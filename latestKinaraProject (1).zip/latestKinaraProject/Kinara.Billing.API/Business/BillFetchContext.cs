﻿using Kinara.Billing.Data;
using Kinara.Billing.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.API.Business
{
    public class BillFetchContext : IBillFetchContext
    {
        private readonly IBillFetchService _billFetchService;
        public BillFetchContext(IBillFetchService billFetchService)
        {
            _billFetchService = billFetchService;
        }

        public CollectionDues GetAlternateBill(string laNo)
        {
            return _billFetchService.GetAlternateBill(laNo);
        }

        public PartnerDetails GetPartnerDetails(string partner_guid)
        {
            return _billFetchService.GetPartnerDetails(partner_guid);
        }

        public string SaveDues(CollectionDues cd)
        {
            return _billFetchService.SaveDues(cd);
        }
        public BillPaymentDetails GetBillDetails(PaymentDetails BillPymt)
        {
            return _billFetchService.GetBillDetails(BillPymt);
        }

        public string UdatePerdixCollectionPostStatus(BillPaymentDetails bpd)
        {
            return _billFetchService.UdatePerdixCollectionPostStatus(bpd);
        }
    }
}
