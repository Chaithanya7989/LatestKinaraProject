﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Billing.API.Business
{
    public interface ITokenManager
    {
        bool ValidateToken(string token);
    }
}
