﻿using Kinara.Billing.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.API.Business
{
    public interface IBillFetchContext
    {
        PartnerDetails GetPartnerDetails(string partner_guid);
        CollectionDues GetAlternateBill(string laNo);
        string SaveDues(CollectionDues cd);
        BillPaymentDetails GetBillDetails(PaymentDetails BillPymt);
        string UdatePerdixCollectionPostStatus(BillPaymentDetails bpd);
    }
}
