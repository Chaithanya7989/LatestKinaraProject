﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Kinara.Billing.API.Business;
using Kinara.Billing.Data.Model;
using Kinara.Capital.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;

namespace Kinara.Billing.API.Controllers
{
    [Route("api/bills/[controller]")]
    [ApiController]
    public class FetchController : ControllerBase
    {
        private static IConfiguration _config;
        public static string access_token;
        public static string baseURL;
        public static RestClient client = new RestClient();
        private readonly IBillFetchContext _billFetchContext;
        public FetchController(IConfiguration config, IBillFetchContext billFetchContext)
        {
            _config = config;
            baseURL = (_config["Perdix:BaseURL"]);
            client = new RestClient(baseURL);
            _billFetchContext = billFetchContext;
        }

        [HttpPost]
        #region Recent Working Code
        public IActionResult Fetch([FromBody] CustomerInput customer)
        {
            IActionResult response = Unauthorized();

            var resp = GeneratePerdixToken(customer);
            //response = Ok(new { token = tokenString });
            if (resp.Result.BillModel.billDetails.billFetchStatus == "NOT_SUPPORTED")
            {
                throw new CustomException(ErrorCodes.SE001.ToString(), _config);
                //response = NotFound(new { error = dp.error, status = 404, success = false });

            }
            else if (resp.Result.BillModel.billDetails.billFetchStatus == "NO_OUTSTANDING")
            {
                throw new CustomException(ErrorCodes.SE001.ToString(), _config);

                //response = NotFound(new { error = dp.error, status = 404, success = false });
            }
            else { response = Ok(new { data = resp.Result.BillModel, status = 200, success = true }); }

            //}

            return response;
        }

        #endregion

        public async Task<FetchBill> GeneratePerdixToken(CustomerInput customer)
        {
            PerdixToken ptoken = new PerdixToken();
            string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes("application" + ":" + "mySecretOAuthSecret"));
            var request = new RestRequest("/oauth/token", Method.POST);
            // easily add HTTP Headers
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Authorization", "Basic " + svcCredentials);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("grant_type", "password");
            request.AddParameter("username", _config["Perdix:username"]);
            request.AddParameter("password", _config["Perdix:password"]);
            request.AddParameter("scope", "read write");
            request.AddParameter("client_secret", "mySecretOAuthSecret");
            request.AddParameter("client_id", "application");

            // execute the request
            IRestResponse resp = client.Execute(request);
            var content = resp.Content; // raw content as string

            // or automatically deserialize result
            // return content type is sniffed but can be explicitly set via RestClient.AddHandler();
            var resp1 = client.Execute<PerdixToken>(request);
            access_token = resp1.Data.access_token;
            customer.access_token = resp1.Data.access_token;

            FetchBill cdue = new FetchBill();
            CollectionDues cdue1 = new CollectionDues();
            //mydb.SaveDues(cdue1);
            cdue = await GetCollectionDues(customer);

            return cdue;
        }

        public async Task<FetchBill> GetCollectionDues(CustomerInput customer)
        {
            CollectionDues cdue = new CollectionDues();
            FetchBill fb = new FetchBill();
            BillsModel bm = new BillsModel();
            DisplayErrors dp = new DisplayErrors();
            //List<BillItems> blst = new List<BillItems>();
            Bills bills = new Bills();
            List<Bills> billsList = new List<Bills>();
            BillDetails bldt = new BillDetails();
            Customer cust = new Customer();
            string lano = string.Empty;
            try
            {
                foreach (CustItem ci in customer.customerIdentifiers)
                {
                    if (ci.attributeName.ToUpper() == "loan_number".ToUpper())
                    { lano = ci.attributeValue; }
                }
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(baseURL + "/api/loanaccounts/show/accountId?accountId=" + lano);
                httpWebRequest.Method = WebRequestMethods.Http.Get;
                httpWebRequest.Headers.Add("cache-control", "no-cache");
                httpWebRequest.Headers.Add("Authorization", "Bearer " + customer.access_token);
                httpWebRequest.Accept = "application/json; charset=utf-8";
                string file;
                try
                {
                    var response = (HttpWebResponse)httpWebRequest.GetResponse();
                    using (var sr = new StreamReader(response.GetResponseStream()))
                    {
                        file = sr.ReadToEnd();
                    }
                    cdue = JsonConvert.DeserializeObject<CollectionDues>(file);
                }
                catch (Exception ex)
                {
                    //if (ex.Message.Contains("500"))
                    //{
                    cdue = _billFetchContext.GetAlternateBill(lano);
                    //}
                }
                if (cdue != null)
                {
                    BillItems bi = new BillItems();
                    double tdue = 0.0;
                    //tdue = Convert.ToDouble(cdue.totalFeeDue) + Convert.ToDouble(cdue.bookedNotDuePenalInterest) + Convert.ToDouble(cdue.totalNormalInterestDue) + Convert.ToDouble(cdue.totalPenalInterestDue) + Convert.ToDouble(cdue.totalPrincipalDue);
                    //tdue = Convert.ToDouble(cdue.totalFeeDue) + Convert.ToDouble(cdue.totalDemandDue) + Convert.ToDouble(cdue.bookedNotDuePenalInterest) + Convert.ToDouble(cdue.totalPenalInterestDue);
                    tdue = Convert.ToDouble(cdue.totalFeeDue) + Convert.ToDouble(cdue.totalDemandDue) + Convert.ToDouble(cdue.bookedNotDuePenalInterest);

                    if (tdue <= 1)
                    {
                        cdue = _billFetchContext.GetAlternateBill(lano);
                        tdue = Convert.ToDouble(cdue.totalFeeDue) + Convert.ToDouble(cdue.totalDemandDue) + Convert.ToDouble(cdue.bookedNotDuePenalInterest) + Convert.ToDouble(cdue.totalPenalInterestDue);
                        //Write code to fetch one Advance EMI from Staging Database.
                    }
                    Amount amt = new Amount { currencyCode = "INR", value = Convert.ToInt64(tdue * 100) };
                    AmountObject total = new AmountObject { amount = amt, displayName = "Total Due" };
                    bi.total = total;
                    cdue.TotalBillDue = tdue;
                    if (cdue.isOffline != true)
                    {
                        cdue.BillType = "Dues";
                    }
                    if (tdue > 0)
                    {
                        BillCustomerAccount ca = new BillCustomerAccount();
                        ca.id = cdue.accountId;

                        string BillId = _billFetchContext.SaveDues(cdue);

                        if (BillId != "0")
                        {
                            //blst.Add(bi);

                            bills.billerBillID = BillId;
                            bills.aggregates = bi;
                            bills.amountExactness = "EXACT_DOWN";  //"ANY" "EXACT" "EXACT_UP" "EXACT_DOWN" "RANGE"
                            bills.customerAccount = ca;
                            bills.dueDate = DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddThh:mm:ssZ");
                            //bills.generatedOn = DateTime.SpecifyKind(DateTime.Now.AddDays(-1), DateTimeKind.Utc);
                            bills.generatedOn = DateTime.Now.AddDays(-1).ToUniversalTime().ToString("yyyy-MM-ddThh:mm:ssZ");
                            bills.recurrence = "MONTHLY"; //"ONE_TIME" "DAILY" "WEEKLY" "FORTNIGHTLY" "MONTHLY" "QUARTERLY" "HALF_YEARLY" "YEARLY" "AS_PRESENTED"

                            //AmountValidation amtchk = new AmountValidation();
                            //amtchk.maximum = amt.value;
                            //amtchk.minimum = 50000;
                            //bills.validationRules = amtchk;

                            billsList.Add(bills);
                            bldt.billFetchStatus = "AVAILABLE";//"NOT_SUPPORTED" "NO_OUTSTANDING" "AVAILABLE"
                            bldt.bills = billsList;
                            cust.name = cdue.customer1FirstName;
                            bm.customer = cust;
                        }
                        else
                        {
                            bldt.billFetchStatus = "NO_OUTSTANDING";
                        }
                    }
                    else
                    {
                        bldt.billFetchStatus = "NO_OUTSTANDING";
                    }
                }
                else
                {
                    bldt.billFetchStatus = "NO_OUTSTANDING";
                }
                fb.success = true;
            }
            catch (Exception ex)
            {
                bldt.billFetchStatus = "NOT_SUPPORTED";
                string a = ex.Message;
                fb.success = false;
                dp.error.code = Convert.ToString(Convert.ToInt32(HttpStatusCode.NotFound));
                dp.success = false;
                dp.status = Convert.ToInt32(dp.error.code);
                dp.error.title = "customer-not-found";
                dp.error.detail = "The requested customer was not found in the biller system.";
            }
            //bldt.bills = billsList;
            //bldt.customer = cust;
            bm.billDetails = bldt;
            fb.Error = dp;
            fb.BillModel = bm;
            return fb;
        }
    }
}
