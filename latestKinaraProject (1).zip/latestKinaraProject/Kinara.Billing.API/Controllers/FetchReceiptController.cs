﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Kinara.Billing.API.Business;
using Kinara.Billing.Data.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;

namespace Kinara.Billing.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FetchReceiptController : ControllerBase
    {
        private static IConfiguration _configuration;
        public static string access_token;
        public static string baseURL;
        public static RestClient client = new RestClient();
        private readonly IBillFetchContext _billFetchContext;
        public FetchReceiptController(IConfiguration configuration, IBillFetchContext billFetchContext)
        {
            _configuration = configuration;
            baseURL = (_configuration["Perdix:BaseURL"]);
            client = new RestClient(baseURL);
            _billFetchContext = billFetchContext;
        }

        [HttpPost]
        public IActionResult Fetch([FromBody] PaymentDetails BillPymt)
        {
            IActionResult response = Unauthorized();
            var resp = GetAcknowledgement(BillPymt);
            if (resp.Result.Error.success == true)
            {
                response = Ok(new { data = resp.Result.ReceiptObj, status = 200, success = true });
            }
            else
            {
                response = NotFound(new { error = resp.Result.Error.error, status = 404, success = false });
            }
            return response;
        }

        public async Task<FetchReceiptResp> GetAcknowledgement(PaymentDetails pdt)
        {
            BillPaymentDetails bpd = new BillPaymentDetails();
            FetchReceiptResp frr = new FetchReceiptResp();
            ReceiptOut rctOut = new ReceiptOut();
            DisplayErrors dp = new DisplayErrors();
            bpd = _billFetchContext.GetBillDetails(pdt);
            if (bpd.success == true)
            {
                if (Convert.ToString(bpd.bill_type).ToUpper() == "DUES")
                {
                    //UpdateCollectioninPerdix(bpd);
                }
                dp.success = true;
            }
            else if (bpd.success == false)
            {
                if (bpd.response_message == "no_outstanding_bills")
                {
                    dp.error.code = "bill-already-fulfilled";
                    dp.error.title = "bill-already-fulfilled";
                    dp.error.detail = "Looks like this particular bill has already been fulfilled";
                    dp.error.docURL = "";
                    dp.error.traceID = "";
                }
                dp.success = false;
            }

            frr.Error = dp;
            ReceiptItem rcpti = new ReceiptItem();
            rcpti.date = DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddThh:mm:ssZ");
            rcpti.id = bpd.kinara_ack_no;
            //RepaymentDetails
            //var result = await client.PostAsync("sign_in", content);
            //var token = result.Headers.GetValues("access-token").FirstOrDefault();
            rctOut.receipt = rcpti;
            frr.ReceiptObj = rctOut;
            return frr;
        }

        public void UpdateCollectioninPerdix(BillPaymentDetails bpd)
        {
            try
            {
                PerdixToken ptoken = new PerdixToken();
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes("application" + ":" + "mySecretOAuthSecret"));
                var request = new RestRequest("/oauth/token", Method.POST);
                // easily add HTTP Headers
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("Authorization", "Basic " + svcCredentials);
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddParameter("grant_type", "password");
                request.AddParameter("username", _configuration["Perdix:username"]);
                request.AddParameter("password", _configuration["Perdix:password"]);
                request.AddParameter("scope", "read write");
                request.AddParameter("client_secret", "mySecretOAuthSecret");
                request.AddParameter("client_id", "application");

                // execute the request
                IRestResponse resp = client.Execute(request);
                var content = resp.Content; // raw content as string

                // or automatically deserialize result
                // return content type is sniffed but can be explicitly set via RestClient.AddHandler();
                var resp1 = client.Execute<PerdixToken>(request);
                access_token = resp1.Data.access_token;

                RepaymentDetails repay = new RepaymentDetails();
                repay.accountNumber = bpd.loan_account_no;
                repay.transactionName = "Scheduled Demand";
                repay.instrument = "NEFT";
                repay.reference = bpd.kin_bill_id;
                //repay.transactionDate = "2020-05-24";
                //repay.repaymentDate = "2020-05-24";
                //repay.instrumentDate = "2020-05-24";

                //Uncomment below lines before live run
                repay.transactionDate = DateTime.Now.ToString("yyyy-MM-dd");
                repay.repaymentDate = DateTime.Now.ToString("yyyy-MM-dd");
                repay.instrumentDate = DateTime.Now.ToString("yyyy-MM-dd");

                repay.bankAccountNumber = "Setucollectionaccount";
                repay.remarks = "Online Setu Collection";
                repay.productCode = bpd.product_code;
                repay.urnNo = bpd.business_urn;

                #region Begining of Bill Payment Accounting

                double paymentCalc = 0;
                repay.amount = System.Math.Round(Convert.ToDouble(bpd.payment_details.paymentDetails.amountPaid.value / 100), 2);
                repay.totalNormalInterestDue = 0;
                repay.totalFeeDue = 0;
                repay.totalPenalInterestDue = 0;
                repay.totalPrincipalDue = 0;
                repay.bookedNotDuePenalInterest = 0;

                #endregion
                var http = (HttpWebRequest)WebRequest.Create(new Uri(baseURL + "/api/loanaccounts/repay"));
                http.Accept = "application/json";
                http.ContentType = "application/json";
                http.Headers.Add("cache-control", "no-cache");
                http.Headers.Add("Authorization", "Bearer " + access_token);
                http.Method = "POST";

                var jsonstring = JsonConvert.SerializeObject(repay);

                string parsedContent = jsonstring;
                ASCIIEncoding encoding = new ASCIIEncoding();
                Byte[] bytes = encoding.GetBytes(parsedContent);

                Stream newStream = http.GetRequestStream();
                newStream.Write(bytes, 0, bytes.Length);
                newStream.Close();

                var response = http.GetResponse();

                var stream = response.GetResponseStream();
                var sr = new StreamReader(stream);
                var content1 = sr.ReadToEnd();

                RepaymentDetails rpd = new RepaymentDetails();
                rpd = JsonConvert.DeserializeObject<RepaymentDetails>(content1.ToString());

                bpd.perdix_transactionID = rpd.transactionId;
                bpd.perdix_api_response = rpd.response;

                string pStatus = _billFetchContext.UdatePerdixCollectionPostStatus(bpd);
            }
            catch (Exception ex)
            {

            }
        }
    }
}
