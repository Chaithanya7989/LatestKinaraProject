import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
declare var $: any;
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'kinaracapital';
    //server = 'https://customerportal.kinaracapital.com';
    server = 'http://localhost:53011';
    // server = 'https://emiuat.kinaracapital.com/';
    showCustomer = false;
    userInput: any = {};
    userDetails: any = {};
    captchaImg = '';
    captchatext = '';
    captchaImage = '';
    minimumPayable = '500';
    instance: any;
    apiInProgrss = false;
    token: string = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiIzOWFkNDQ2OC05ZGY4LTRmN2MtOWFhMS0yYjY0MjNiMWI0MWMiLCJqdGkiOiJKb2huIERvZSIsImlhdCI6MTU5MTYxMTYwMH0.yaaPfYVvoijtdLHYvE7WO4Ve-uN0ByAQKupCTVMlLTI";
    razorpay = {
        key_id: 'rzp_live_7tOmn9jxIj18W6'
    };
    // razorpay = {
    //   key_id: 'rzp_test_KBDn0YqgWtwvM7'
    // };

    constructor(private http: HttpClient) {
        //this.getCaptcha();
    }
    getCaptcha() {
        this.http.get(this.server + '/kinaracapital/api/home/getcaptcha').subscribe((resp: any) => {
            this.captchatext = resp.captchaText;
            this.captchaImg = resp.url;
            this.captchaImage = resp.captchaImage;
        });
    }
    refreshCaptcha() {
        this.getCaptcha();
    }
    getLoanDetails() {
        this.userInput.form1Error = '';
        if (!this.userInput.loanId) {
            this.userInput.form1Error = 'Please enter Loan Account Number';
            return;
        }
        if (!this.userInput.loanIdCC) {
            this.userInput.form1Error = 'Please re-enter Loan Account Number';
            return;
        }
        if (this.userInput.loanId !== this.userInput.loanIdCC) {
            this.userInput.form1Error = 'Loan Account Number and Re enter Loan Account Number are not matching';
            return;
        }
        // tslint:disable-next-line:triple-equals
        //if (this.userInput.catpcha != this.captchatext) {
        //  this.userInput.form1Error = 'CAPTCHA validation failed';
        //  this.userInput.catpcha = '';
        //  this.getCaptcha();
        //  return;
        //}
        this.apiInProgrss = true;
        //this.http.get(this.server + '/api/home/getcustomerdetails/?customerId=' +
        //  this.userInput.loanId + '&url=' + this.captchaImage).subscribe((resp: any) => {
        //    this.apiInProgrss = false;
        //    if (resp.status === 'success') {
        //      this.minimumPayable = resp.minimumPayable;
        //      this.userDetails = resp.customerDetails;
        //      this.userDetails.amountType = 'full';
        //      this.userDetails.email = 'payment@kinaracapital.com';
        //this.userDetails.description = "payment"
        //      this.userDetails.amountDue = parseFloat(this.userDetails.payOffAndDueAmount);
        //      this.showCustomer = true;
        //    } else if (resp.status === 'error') {
        //      this.userInput.form1Error = resp.ERROR;
        //    }
        //  }, (error) => {
        //    console.log(error);
        //    this.apiInProgrss = false;
        //  });
        var customerInput = {
            "customerIdentifiers": [
                {
                    "attributeName": "loan_number",
                    "attributeValue": "TLWCS0000001"
                }
            ]
        };
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + this.token
        });
        let options = { headers: headers };
        this.http.post(this.server + '/api/bills/fetch/?fetch', customerInput, options).subscribe((resp: any) => {
            this.apiInProgrss = false;
            console.log(resp);
            if (resp.status === 200) {
                this.minimumPayable = resp.minimumPayable;
                this.userDetails = resp.data.customer;
                //th
                this.userDetails.amountType = 'full';
                this.userDetails.email = 'payment@kinaracapital.com';
                this.userDetails.description = "payment"
                this.userDetails.amountDue = parseFloat(this.userDetails.payOffAndDueAmount == null ? 100 : this.userDetails.payOffAndDueAmount);
                this.showCustomer = true;
                console.log(resp.customerDetails);
            } else if (resp.status === 'error') {
                this.userInput.form1Error = resp.ERROR;
            }
        },
            (error) => {
                console.log(error);
                this.apiInProgrss = false;
            });
        console.log(this.showCustomer);
    }
    proceedPay() {
        this.userDetails.formError = '';
        let amountToPay = 0;
        if (this.userDetails.amountType === 'full') {
            amountToPay = this.userDetails.amountDue;
        } else {
            if (!this.userDetails.amountPay) {
                this.userDetails.formError = 'Please enter paying amount.';
                return;
                // tslint:disable-next-line:radix
            } else if (parseInt(this.userDetails.amountPay) < parseInt(this.minimumPayable)) {
                this.userDetails.formError = 'Minimum payment is ' + this.minimumPayable + '.';
                return;
            } else {
                amountToPay = this.userDetails.amountPay;
            }
        }
        this.userDetails.amount = amountToPay;
        this.http.post(this.server + '/api/home/getorderid', this.userDetails).subscribe((resp: any) => {
            if (resp.invokeMaintanance) {
                window.location.href = this.server;
            } else {
                if (resp.status === 'success') {
                    this.userDetails.orderId = resp.orderId;
                    this.userDetails.loanAccountNumber = resp.loanAccountNumber;
                    console.log('loan account number ' + this.userDetails.loanAccountNumber);
                    setTimeout(() => {
                        const element = document.getElementById('razorpay') as HTMLFormElement;
                        element.submit();
                    }, 100);
                } else if (resp.status === 'error') {
                    this.userDetails.formError = resp.ERROR;
                }
            }
        });
    }
}
