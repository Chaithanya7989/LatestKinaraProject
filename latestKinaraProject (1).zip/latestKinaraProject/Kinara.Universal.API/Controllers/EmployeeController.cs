﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kinara.Universal.API.Business;
using Kinara.Universal.Data.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Kinara.Universal.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]


    public class EmployeeController : ControllerBase
    {
        public IEmployeeContext _employeeContext;

        public EmployeeController(IEmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
        }

        [HttpPost("employees")]
        public IActionResult FetchEmployees(EmployeeInputParams employeeInputParams)
        {
            IActionResult authorized = Unauthorized();
            var resp = _employeeContext.GetEmployeeViewModel(employeeInputParams);
            var response = Ok(new { status = 200, success = true, data = resp });
            return response;
        }

        [HttpPost("login")]
        public IActionResult EmployeeLogin(EmployeeInputParams employeeInputParams)
        {
            var resp = _employeeContext.EmployeeLogin(employeeInputParams);
            var response = Ok(new { status = 200, success = true, data = resp });
            return response;
        }
    }
}
