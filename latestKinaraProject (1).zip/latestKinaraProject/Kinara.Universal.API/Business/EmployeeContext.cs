﻿using Kinara.Universal.Data.Model;
using Kinara.Universal.Data.Services;
using Kinara.Universal.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Universal.API.Business
{
    public class EmployeeContext : IEmployeeContext
    {
        private readonly IEmployeeService _employeeService;
        public EmployeeContext(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        public LoginViewModel EmployeeLogin(EmployeeInputParams employeeInputParams)
        {
            return _employeeService.EmployeeLogin(employeeInputParams);
        }

        public List<EmployeeViewModel> GetEmployeeViewModel(EmployeeInputParams employeeInputParams)
        {
            return _employeeService.GetEmployeeService(employeeInputParams);
        }
    }
}
