﻿using Kinara.Universal.Data.ViewModels;
using System.Collections.Generic;

namespace Kinara.Universal.API.Business
{
    public interface IEmployeeContext
    {
        List<EmployeeViewModel> GetEmployeeViewModel(EmployeeInputParams employeeInputParams);

        LoginViewModel EmployeeLogin(EmployeeInputParams employeeInputParams);
    }
}
