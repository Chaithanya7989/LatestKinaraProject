﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Capital.Security
{
    public interface ITokenManager
    {
        bool ValidateToken(string token, bool isDbCallRequired = false);
    }
}
