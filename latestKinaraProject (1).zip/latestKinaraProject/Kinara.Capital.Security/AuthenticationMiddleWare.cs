﻿using Kinara.Capital.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Kinara.Capital.Security
{
    [ExcludeFromCodeCoverage]
    public class AuthenticationMiddleWare
    {
        private readonly RequestDelegate _next;
        private ITokenManager _tokenManager;
        public AuthenticationMiddleWare(RequestDelegate next, ITokenManager tokenManager)
        {
            _next = next;
            _tokenManager = tokenManager;
        }

        public async Task Invoke(HttpContext context)
        {
            if (!IsTokenValid(context))
            {
                throw new UnauthorizedAccessException();
            }
            await _next(context).ConfigureAwait(false);
        }

        private string GetJwtAccessToken(HttpContext context)
        {
            var request = context.Request;
            StringValues authorization;
            if (request.Headers.TryGetValue(Constants.AuthorizationTokenHeader, out authorization) && authorization.Count > 0)
            {
                var authString = authorization[0];
                var segments = authString.Split(new char[] { ' ' });
                if (segments != null && segments.Length > 1 && segments[0] == Constants.BearerAuthTokenKey)
                {
                    return segments[1];
                }
            }
            return null;
        }

        private bool IsTokenValid(HttpContext context)
        {
            string authJwtToken = GetJwtAccessToken(context);
            if (_tokenManager.ValidateToken(authJwtToken))
            {
                return true;
            }
            return false;
        }
    }
}
