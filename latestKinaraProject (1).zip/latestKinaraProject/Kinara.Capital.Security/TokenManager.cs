﻿using Kinara.Billing.Data;
using Kinara.Billing.Data.Model;
using Kinara.Capital.Common;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace Kinara.Capital.Security
{
    public class TokenManager : ITokenManager
    {
        private readonly IConfiguration _configuration;
        private readonly IBillFetchService _billFetchService;
        public TokenManager(IConfiguration configuration, IBillFetchService billFetchService)
        {
            _configuration = configuration;
            _billFetchService = billFetchService;
        }
        public bool ValidateToken(string token, bool isDbCallRequired)
        {
            if (token == null || token.Length == 0)
            {
                throw new CustomException(ErrorCodes.GE002.ToString(), _configuration);
            }
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var handler = new JwtSecurityTokenHandler();
            try
            {
                var tokenSecure = handler.ReadToken(token) as SecurityToken;
            }
            catch (Exception ex)
            {
                throw new CustomException(ErrorCodes.GE002.ToString(), _configuration);
            }
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = key,
                ValidateIssuer = false,
                ValidateAudience = true,
                ValidateLifetime = false,
                ValidIssuer = _configuration["Jwt:Issuer"],
                ValidAudience = _configuration["Jwt:Audience"],
            };
            SecurityToken securityToken;
            ClaimsPrincipal principal;
            try
            {
                principal = handler.ValidateToken(token, validations, out securityToken);
            }
            catch (Exception e)
            {
                if (e.Message.Contains("Signature validation failed"))
                {
                    throw new CustomException(ErrorCodes.GE003.ToString(), _configuration);
                }
                else
                {
                    throw new CustomException(ErrorCodes.GE004.ToString(), _configuration);
                }
            }
            var jwtSecurityToken = securityToken as JwtSecurityToken;
            if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                throw new CustomException(ErrorCodes.GE002.ToString(), _configuration);
            }

            string tokenTime = principal.Claims.Where(c => c.Type == "iat").Select(c => c.Value).SingleOrDefault();
            string audience = principal.Claims.Where(c => c.Type == "aud").Select(c => c.Value).SingleOrDefault();
            string jwtId = principal.Claims.Where(c => c.Type == "jti").Select(c => c.Value).SingleOrDefault();
            if (!string.IsNullOrEmpty(tokenTime))
            {
                DateTime tTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(Convert.ToInt64(tokenTime));
                DateTime cTime = new DateTime();
                cTime = DateTime.UtcNow;
                if (cTime > tTime.AddMinutes(Convert.ToDouble(_configuration["jwt:ExpiryMins"])))
                {
                    throw new CustomException(ErrorCodes.GE006.ToString(), _configuration);
                }
            }
            if (audience == null || jwtId == null)
            {
                throw new CustomException(ErrorCodes.GE004.ToString(), _configuration);
            }
            if (!String.IsNullOrEmpty(audience) && isDbCallRequired)
            {
                PartnerDetails pd = new PartnerDetails();
                pd = _billFetchService.GetPartnerDetails(audience);
                if (pd.success == false || pd.partner_info == null)
                {
                    throw new CustomException(ErrorCodes.GE005.ToString(), _configuration);
                }
            }
            return true;
        }
    }
}
