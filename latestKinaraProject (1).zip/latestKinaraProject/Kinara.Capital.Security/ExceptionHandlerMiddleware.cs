﻿using Kinara.Capital.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading.Tasks;

namespace Kinara.Capital.Security
{
    [ExcludeFromCodeCoverage]
    public class ExceptionHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private IConfiguration _configuration;

        public ExceptionHandlerMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _configuration = configuration;
        }

        public async Task Invoke(HttpContext context) //can inject logger mechanism as well
        {
            DateTime executionStartTime = DateTime.UtcNow;
            try
            {
                await _next(context).ConfigureAwait(false);
            }
            catch(UnauthorizedAccessException uEx)
            {
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                context.Response.ContentType = Constants.JsonContentType;
                await context.Response.WriteAsync(JsonConvert.SerializeObject(
                    new CustomException(ErrorCodes.GE005.ToString(),_configuration).GetErrorObject())).ConfigureAwait(false);
            }
            catch (CustomException cEx)
            {
                context.Response.StatusCode = (int)HttpStatusCode.OK;
                context.Response.ContentType = Constants.JsonContentType;
                await context.Response.WriteAsync(JsonConvert.SerializeObject(cEx.GetErrorObject())).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                context.Response.ContentType = Constants.JsonContentType;
                await context.Response.WriteAsync(JsonConvert.SerializeObject(new CustomException(
                    ErrorCodes.Default.ToString(), _configuration).GetErrorObject())).ConfigureAwait(false);
            }
        }
    }
}
