﻿using Kinara.Billing.Data.Model;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Kinara.Billing.Data
{
    public class TokenService : ITokenService
    {
        private readonly IConfiguration _configuration;
        private readonly string billingConnection;
        public TokenService(IConfiguration configuration)
        {
            _configuration = configuration;
            billingConnection = _configuration["ConnectionStrings:DataConnection"];
        }
        public PartnerDetails GetPartnerDetails(string audience)
        {
            PartnerDetails partnerDetails = new PartnerDetails { status = "Failed", success = false };
            try
            {
                using (MySqlConnection connection = new MySqlConnection(billingConnection))
                {
                    connection.Open();
                    using (MySqlCommand cmd = new MySqlCommand("api_get_partner_details", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("iapi_uid", audience);
                        MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
                        while (mySqlDataReader.Read())
                        {
                            partnerDetails.partner_info = new Partner
                            {
                                partner_id = Convert.ToInt64(mySqlDataReader["id"]),
                                partner_name = Convert.ToString(mySqlDataReader["aggr_name"]),
                                partner_guid = Convert.ToString(mySqlDataReader["api_uid"]),
                                partner_secret_key = Convert.ToString(mySqlDataReader["api_secret_key"])
                            };
                            partnerDetails.status = "OK";
                            partnerDetails.success = true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                partnerDetails = new PartnerDetails
                {
                    status = "Failed",
                    success = false
                };
            }
            return partnerDetails;
        }
    }
}
