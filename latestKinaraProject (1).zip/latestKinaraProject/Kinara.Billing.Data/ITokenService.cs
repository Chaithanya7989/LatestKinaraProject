﻿using Kinara.Billing.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Billing.Data
{
    public interface ITokenService
    {
        PartnerDetails GetPartnerDetails(string audience);
    }
}
