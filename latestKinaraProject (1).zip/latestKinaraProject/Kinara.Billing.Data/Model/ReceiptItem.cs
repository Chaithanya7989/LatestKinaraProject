﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class ReceiptItem
    {
        public string date { get; set; }
        public string id { get; set; }
    }
}
