﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class CustomError
    {
        public string code { get; set; }
        public string title { get; set; }
        public string detail { get; set; }
        public string docURL { get; set; }
        public string traceID { get; set; }
    }
}
