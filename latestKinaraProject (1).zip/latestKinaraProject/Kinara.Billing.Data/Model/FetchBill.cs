﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class FetchBill
    {
        public BillsModel BillModel { get; set; }
        public DisplayErrors Error { get; set; }
        public bool success { get; set; }
    }
}
