﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class RepaymentDetails
    {
        public string accountNumber { get; set; }
        public double amount { get; set; }
        public string transactionName { get; set; }
        public string transactionDate { get; set; }
        public string instrument { get; set; }
        public string reference { get; set; }
        public string repaymentDate { get; set; }
        public string bankAccountNumber { get; set; }
        public string instrumentDate { get; set; }
        public string remarks { get; set; }
        public string productCode { get; set; }
        public string urnNo { get; set; }
        public double totalNormalInterestDue { get; set; }
        public double totalFeeDue { get; set; }
        public double totalPenalInterestDue { get; set; }
        public double totalPrincipalDue { get; set; }
        public double bookedNotDuePenalInterest { get; set; }
        public string transactionId { get; set; }
        public string response { get; set; }
    }
}
