﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class PaymentDetails
    {
        public string billerBillID { get; set; }
        public TransactionDetails paymentDetails { get; set; }
        public string platformBillID { get; set; }
        public string platformMobNo { get; set; }
    }
}
