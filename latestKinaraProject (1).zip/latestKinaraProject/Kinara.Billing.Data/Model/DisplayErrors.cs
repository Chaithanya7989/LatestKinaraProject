﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class DisplayErrors
    {
        public DisplayErrors()
        {
            error = new CustomError();
        }
        public Int32 status { get; set; }
        public bool success { get; set; }
        public CustomError error { get; set; }
    }
}
