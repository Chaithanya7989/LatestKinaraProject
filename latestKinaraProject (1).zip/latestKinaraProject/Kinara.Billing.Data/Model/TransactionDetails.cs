﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class TransactionDetails
    {
        public Amount amountPaid { get; set; }
        public Amount billAmount { get; set; }
        public string platformTransactionRefID { get; set; }
        public string uniquePaymentRefID { get; set; }
    }
}
