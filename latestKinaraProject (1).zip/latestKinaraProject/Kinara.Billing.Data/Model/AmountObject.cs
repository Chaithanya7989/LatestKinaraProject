﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class AmountObject
    {
        public string displayName { get; set; }
        public Amount amount { get; set; }
    }
}
