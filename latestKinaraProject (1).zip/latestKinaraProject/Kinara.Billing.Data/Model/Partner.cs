﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class Partner
    {
        public Int64 partner_id { get; set; }
        public string partner_name { get; set; }
        public string partner_guid { get; set; }
        public string partner_secret_key { get; set; }
    }
}
