﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class UserModel
    {
        public string user_name { get; set; }
        public string password { get; set; }
        public string email_address { get; set; }
        public DateTime date_of_joing { get; set; }
    }
}
