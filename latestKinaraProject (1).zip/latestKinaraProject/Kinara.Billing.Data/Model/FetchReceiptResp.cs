﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class FetchReceiptResp
    {
        public ReceiptOut ReceiptObj { get; set; }
        public DisplayErrors Error { get; set; }
    }
}
