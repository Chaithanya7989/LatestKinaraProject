﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class BillPaymentDetails
    {
        public string kin_bill_id { get; set; }
        public string loan_account_no { get; set; }
        public string product_code { get; set; }
        public string product_type { get; set; }
        public string loan_type { get; set; }
        public string business_urn { get; set; }
        public double tot_principle_due { get; set; }
        public double tot_normal_nterest_due { get; set; }
        public double tot_penal_interest_due { get; set; }
        public double booked_not_due_penal_interest_due { get; set; }
        public double tot_fee_due { get; set; }
        public double tot_bill_amount { get; set; }
        public string bill_type { get; set; }
        public string updated_perdix { get; set; }
        public PaymentDetails payment_details { get; set; }
        public bool success { get; set; }
        public string response_message { get; set; }
        public string kinara_ack_no { get; set; }
        public string perdix_transactionID { get; set; }
        public string perdix_api_response { get; set; }
    }
}
