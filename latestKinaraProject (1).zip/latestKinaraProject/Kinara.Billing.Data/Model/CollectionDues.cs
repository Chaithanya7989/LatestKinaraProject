﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class CollectionDues
    {
        public string BillID { get; set; }
        public string accountId { get; set; }
        public string productType { get; set; }
        public string productCode { get; set; }
        public string accountName { get; set; }
        public string customerId1 { get; set; }
        //public string business_urn { get; set; }
        public string customer1FirstName { get; set; }
        public string customer1MiddleName { get; set; }
        public string customer1LastName { get; set; }
        public string customer1Phone1 { get; set; }
        public string customerId2 { get; set; }
        public string customer2FirstName { get; set; }
        public string customer2MiddleName { get; set; }
        public string customer2LastName { get; set; }
        public string customer2Phone1 { get; set; }
        public string totalPrincipalDue { get; set; }
        public string totalNormalInterestDue { get; set; }
        public string totalPenalInterestDue { get; set; }
        public string bookedNotDuePenalInterest { get; set; }
        public string totalFeeDue { get; set; }
        public string totalDemandDue { get; set; }
        public double TotalBillDue { get; set; }
        public string BillType { get; set; }
        public bool success { get; set; }
        public string status { get; set; }
        public bool isOffline { get; set; }
    }
}
