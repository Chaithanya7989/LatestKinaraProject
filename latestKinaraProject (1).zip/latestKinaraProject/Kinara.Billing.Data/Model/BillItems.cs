﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class BillItems
    {
        //public AmountObject discount { get; set; }
        //public AmountObject fee { get; set; }
        //public AmountObject subTotal { get; set; }
        //public AmountObject tax { get; set; }
        public AmountObject total { get; set; }
    }
}
