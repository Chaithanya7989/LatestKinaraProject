﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class Bills
    {
        public BillItems aggregates { get; set; }
        public string amountExactness { get; set; }
        public string billerBillID { get; set; }
        public BillCustomerAccount customerAccount { get; set; }
        public string dueDate { get; set; }
        public string generatedOn { get; set; }
        public string recurrence { get; set; }
        //public AmountValidation validationRules { get; set; }
    }
}
