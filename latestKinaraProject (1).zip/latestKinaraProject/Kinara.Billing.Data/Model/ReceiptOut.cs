﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class ReceiptOut
    {
        public ReceiptItem receipt { get; set; }
    }
}
