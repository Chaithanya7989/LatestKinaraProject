﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    
    public class BillsModel
    {
        public BillDetails billDetails { get; set; }
        public Customer customer { get; set; }
        //public Int32 status { get; set; }
        //public Boolean success { get; set; }
    }
}
