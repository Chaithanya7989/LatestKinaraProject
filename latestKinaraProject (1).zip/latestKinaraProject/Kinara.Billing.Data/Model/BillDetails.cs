﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class BillDetails
    {
        public string billFetchStatus { get; set; }
        public List<Bills> bills { get; set; }
    }
}
