﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class CustItem
    {
        public string attributeName { get; set; }
        public string attributeValue { get; set; }
    }
}
