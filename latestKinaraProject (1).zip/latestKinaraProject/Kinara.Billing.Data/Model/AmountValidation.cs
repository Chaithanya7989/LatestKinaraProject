﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Billing.Data.Model
{
    public class AmountValidation
    {
        public Int64 minimum { get; set; }
        public Int64 maximum { get; set; }
    }
}
