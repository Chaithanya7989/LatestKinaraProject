﻿using Kinara.Billing.Data.Model;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Data;

namespace Kinara.Billing.Data
{
    public class BillFetchService : IBillFetchService
    {
        private MySqlConnection mcon;
        private MySqlCommand cmd;
        private IConfiguration _configuration;
        private readonly string myCon = string.Empty;
        public BillFetchService(IConfiguration configuration)
        {
            _configuration = configuration;
            if (_configuration["ConnectionStrings:DataConnection"] != null)
            {
                myCon = _configuration["ConnectionStrings:DataConnection"];
                mcon = new MySqlConnection(myCon);
            }
        }
        public CollectionDues GetAlternateBill(string laNo)
        {
            CollectionDues cd = new CollectionDues();
            cd = GetOfflineOverDues(laNo);
            if (cd.success == false)
            {
                cd = GetOfflineOverallDemand(laNo);
            }
            return cd;
        }

        private CollectionDues GetOfflineOverallDemand(string laNo)
        {
            CollectionDues cd = new CollectionDues();
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "billsapi_OverallDemand";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("iAccountnumber", laNo);
                    MySqlDataAdapter mda = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    mda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        cd.accountId = Convert.ToString(dt.Rows[0]["loan_account_no"]);
                        cd.accountName = Convert.ToString(dt.Rows[0]["business_name"]);
                        cd.BillType = "AdvanceEMI";
                        cd.bookedNotDuePenalInterest = "0.0";
                        cd.customer1FirstName = Convert.ToString(dt.Rows[0]["business_name"]);
                        cd.customer1Phone1 = Convert.ToString(dt.Rows[0]["Mobile_no"]);
                        cd.customer2FirstName = Convert.ToString(dt.Rows[0]["applicant_fname"]);
                        cd.customerId1 = Convert.ToString(dt.Rows[0]["business_urn"]);
                        cd.productCode = Convert.ToString(dt.Rows[0]["product_code"]);
                        cd.productType = "Loans";
                        cd.TotalBillDue = Convert.ToDouble(dt.Rows[0]["tot_bill_amount"]);
                        cd.totalDemandDue = Convert.ToString(dt.Rows[0]["tot_demand_due"]);
                        cd.totalFeeDue = Convert.ToString(dt.Rows[0]["tot_fee_due"]);
                        cd.totalNormalInterestDue = Convert.ToString(dt.Rows[0]["tot_normal_interest_due"]);
                        cd.totalPenalInterestDue = Convert.ToString(dt.Rows[0]["tot_penal_interest_due"]);
                        cd.totalPrincipalDue = Convert.ToString(dt.Rows[0]["tot_principle_due"]);
                        cd.success = true;
                        cd.status = "OK";
                        cd.isOffline = true;
                    }
                    else
                    {
                        cd.success = false;
                        cd.status = "OK";
                    }
                }
                else
                {
                    cd.success = false;
                    cd.status = "OK";
                }
            }
            catch (Exception ex)
            {

                cd.success = false;
                cd.status = "failed";
            }
            finally
            {
                CloseCon();
            }
            return cd;
        }

        private CollectionDues GetOfflineOverDues(string laNo)
        {
            CollectionDues cd = new CollectionDues();
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "billsapi_OverdueAccounts";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("iAccountnumber", laNo);
                    MySqlDataAdapter mda = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    mda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        cd.accountId = Convert.ToString(dt.Rows[0]["loan_account_no"]);
                        cd.accountName = Convert.ToString(dt.Rows[0]["business_name"]);
                        cd.BillType = "OfflineDues";
                        cd.bookedNotDuePenalInterest = "0.0";
                        cd.customer1FirstName = Convert.ToString(dt.Rows[0]["business_name"]);
                        cd.customer1Phone1 = Convert.ToString(dt.Rows[0]["Mobile_no"]);
                        cd.customer2FirstName = Convert.ToString(dt.Rows[0]["Name"]);
                        cd.customerId1 = Convert.ToString(dt.Rows[0]["business_urn"]);
                        cd.productCode = Convert.ToString(dt.Rows[0]["product_code"]);
                        cd.productType = Convert.ToString(dt.Rows[0]["product_type"]); ;
                        cd.TotalBillDue = Convert.ToDouble(dt.Rows[0]["tot_bill_amount"]);
                        cd.totalDemandDue = Convert.ToString(dt.Rows[0]["tot_demand_due"]);
                        cd.totalFeeDue = Convert.ToString(dt.Rows[0]["tot_fee_due"]);
                        cd.totalNormalInterestDue = Convert.ToString(dt.Rows[0]["tot_normal_interest_due"]);
                        cd.totalPenalInterestDue = Convert.ToString(dt.Rows[0]["tot_penal_interest_due"]);
                        cd.totalPrincipalDue = Convert.ToString(dt.Rows[0]["tot_principle_due"]);
                        cd.success = true;
                        cd.status = "OK";
                        cd.isOffline = true;
                    }
                    else
                    {
                        cd.success = false;
                        cd.status = "OK";
                    }
                }
                else
                {
                    cd.success = false;
                    cd.status = "OK";
                }
            }
            catch (Exception ex)
            {
                cd.success = false;
                cd.status = "failed";
            }
            finally
            {
                CloseCon();
            }
            return cd;
        }
        public string SaveDues(CollectionDues cd)
        {
            string billID = string.Empty;
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "api_save_payment_bills";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("iloan_account_no", cd.accountId);
                    cmd.Parameters.AddWithValue("ibusiness_urn", cd.customerId1);
                    cmd.Parameters.AddWithValue("iproduct_code", cd.productCode);
                    cmd.Parameters.AddWithValue("iproduct_type", cd.productType);
                    cmd.Parameters.AddWithValue("iloan_type", cd.accountName);
                    cmd.Parameters.AddWithValue("ibusiness_name", cd.customer1FirstName);
                    cmd.Parameters.AddWithValue("icustomer_phone", cd.customer1Phone1);
                    cmd.Parameters.AddWithValue("iapplicant_fname", cd.customer2FirstName);
                    cmd.Parameters.AddWithValue("iapplicant_mname", cd.customer2MiddleName);
                    cmd.Parameters.AddWithValue("iapplicant_lname", cd.customer2LastName);
                    cmd.Parameters.AddWithValue("iapplicant_phone", cd.customer2Phone1);
                    cmd.Parameters.AddWithValue("itot_principle_due", cd.totalPrincipalDue);
                    cmd.Parameters.AddWithValue("itot_normal_interest_due", cd.totalNormalInterestDue);
                    cmd.Parameters.AddWithValue("itot_penal_interest_due", cd.totalPenalInterestDue);
                    cmd.Parameters.AddWithValue("ibooked_not_due_penal_interest_due", cd.bookedNotDuePenalInterest);
                    cmd.Parameters.AddWithValue("itot_fee_due", cd.totalFeeDue);
                    cmd.Parameters.AddWithValue("itot_bill_amount", cd.TotalBillDue);
                    cmd.Parameters.AddWithValue("itotalDemandDue", cd.totalDemandDue);
                    cmd.Parameters.AddWithValue("ibill_type", cd.BillType);
                    cmd.Parameters.AddWithValue("oBillID", MySqlDbType.Int64);
                    cmd.Parameters["oBillID"].Direction = ParameterDirection.Output;

                    int i = Convert.ToInt32(cmd.ExecuteNonQuery());
                    billID = Convert.ToString(cmd.Parameters["oBillID"].Value.ToString());
                }
            }
            catch (Exception ex)
            {
                billID = "0";
            }
            finally
            {
                CloseCon();
            }
            return billID;
        }
        private bool OpenCon()
        {
            bool res = false;
            try
            {
                mcon = new MySqlConnection(myCon);
                if (mcon.State != ConnectionState.Open)
                {
                    mcon.Open();
                }
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }

        private bool CloseCon()
        {
            bool res = false;
            try
            {
                mcon = new MySqlConnection(myCon);
                if (mcon.State == ConnectionState.Open)
                {
                    mcon.Close();
                }
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }

        public PartnerDetails GetPartnerDetails(string partner_guid)
        {
            PartnerDetails pd = new PartnerDetails();
            Partner prtnr = new Partner();
            string ackNo = string.Empty;
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "api_get_partner_details";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("iapi_uid", partner_guid);
                    MySqlDataAdapter mda = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    mda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        prtnr.partner_id = Convert.ToInt64(dt.Rows[0]["id"]);
                        prtnr.partner_name = Convert.ToString(dt.Rows[0]["aggr_name"]);
                        prtnr.partner_guid = Convert.ToString(dt.Rows[0]["api_uid"]);
                        prtnr.partner_secret_key = Convert.ToString(dt.Rows[0]["api_secret_key"]);
                        pd.success = true;
                        pd.status = "OK";
                        pd.partner_info = prtnr;
                    }
                    else
                    {
                        pd.success = false;
                        pd.status = "OK";
                    }
                }
            }
            catch (Exception ex)
            {
                pd.status = "Failed";
                pd.success = false;
            }
            finally
            {
                CloseCon();
            }
            return pd;
        }

        public BillPaymentDetails GetBillDetails(PaymentDetails BillPymt)
        {
            BillPaymentDetails bpd = new BillPaymentDetails();
            string ackNo = string.Empty;
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "api_get_bill_details";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("ibillID", BillPymt.billerBillID);
                    MySqlDataAdapter mda = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    mda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        bpd.kin_bill_id = BillPymt.billerBillID;
                        bpd.loan_account_no = Convert.ToString(dt.Rows[0]["loan_account_no"]);
                        bpd.product_code = Convert.ToString(dt.Rows[0]["product_code"]);
                        bpd.product_type = Convert.ToString(dt.Rows[0]["product_type"]);
                        bpd.loan_type = Convert.ToString(dt.Rows[0]["loan_type"]);
                        bpd.business_urn = Convert.ToString(dt.Rows[0]["business_urn"]);
                        bpd.tot_principle_due = Convert.ToDouble(dt.Rows[0]["tot_principle_due"]);
                        bpd.tot_normal_nterest_due = Convert.ToDouble(dt.Rows[0]["tot_normal_interest_due"]);
                        bpd.tot_penal_interest_due = Convert.ToDouble(dt.Rows[0]["tot_penal_interest_due"]);
                        bpd.booked_not_due_penal_interest_due = Convert.ToDouble(dt.Rows[0]["booked_not_due_penal_interest_due"]);
                        bpd.tot_fee_due = Convert.ToDouble(dt.Rows[0]["tot_fee_due"]);
                        bpd.tot_bill_amount = Convert.ToDouble(dt.Rows[0]["tot_bill_amount"]);
                        bpd.bill_type = Convert.ToString(dt.Rows[0]["bill_type"]);
                        bpd.updated_perdix = Convert.ToString(dt.Rows[0]["updated_perdix"]);
                        bpd.payment_details = BillPymt;
                        bpd.success = true;
                        bpd.kinara_ack_no = bpd.product_code + DateTime.Now.ToString("ddMMyyyyHHmm") + BillPymt.billerBillID;
                        bpd = UpdateTranDetails(bpd);
                    }
                    else
                    {
                        bpd.success = false;
                        bpd.response_message = "no_outstanding_bills";
                    }
                }
            }
            catch (Exception ex)
            {
                bpd.success = false;
            }
            finally
            {
                CloseCon();
            }
            return bpd;
        }
        private BillPaymentDetails UpdateTranDetails(BillPaymentDetails bpd)
        {
            string pStatus = string.Empty;
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "api_update_payment_details";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("ibillID", Convert.ToInt64(bpd.payment_details.billerBillID));
                    cmd.Parameters.AddWithValue("iplatform_mob_no", bpd.payment_details.platformMobNo);
                    cmd.Parameters.AddWithValue("ipayment_Status", "TRANSACTION_SUCCESSFUL");
                    cmd.Parameters.AddWithValue("iplatform_bill_no", bpd.payment_details.platformBillID);
                    cmd.Parameters.AddWithValue("itran_ref_no", bpd.payment_details.paymentDetails.uniquePaymentRefID);
                    //cmd.Parameters.AddWithValue("itran_amount", bpd.payment_details.paymentDetails.amountPaid.value);
                    Double amt = 0.00;
                    amt = System.Math.Round((Convert.ToDouble(bpd.payment_details.paymentDetails.amountPaid.value / 100)), 2);
                    cmd.Parameters.AddWithValue("itran_amount", amt);
                    cmd.Parameters.AddWithValue("ikin_receipt_no", bpd.kinara_ack_no);
                    cmd.Parameters.AddWithValue("oProc_status", MySqlDbType.String);
                    cmd.Parameters["oProc_status"].Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    pStatus = Convert.ToString(cmd.Parameters["oProc_status"].Value.ToString());
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                CloseCon();
            }
            return bpd;
        }

        public string UdatePerdixCollectionPostStatus(BillPaymentDetails bpd)
        {
            string pStatus = string.Empty;
            try
            {
                if (OpenCon())
                {
                    cmd = mcon.CreateCommand();
                    cmd.CommandTimeout = 300;
                    cmd.CommandText = "api_update_collection_post_status";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("ibillID", bpd.payment_details.billerBillID);
                    cmd.Parameters.AddWithValue("itranID", bpd.perdix_transactionID);
                    cmd.Parameters.AddWithValue("itranResponse", bpd.perdix_api_response);
                    cmd.Parameters.AddWithValue("oProc_status", MySqlDbType.String);
                    cmd.Parameters["oProc_status"].Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    pStatus = Convert.ToString(cmd.Parameters["oProc_status"].Value.ToString());
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                CloseCon();
            }
            return pStatus;
        }
    }
}
