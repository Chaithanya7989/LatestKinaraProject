﻿using Kinara.Billing.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Billing.Data
{
    public interface IMyDbCalls
    {
        CollectionDues GetAlternateBill(string laNo);
        string SaveDues(CollectionDues cd);
        PartnerDetails GetPartnerDetails(string partner_guid);
        BillPaymentDetails GetBillDetails(PaymentDetails BillPymt);
        string UdatePerdixCollectionPostStatus(BillPaymentDetails bpd);
    }

}
