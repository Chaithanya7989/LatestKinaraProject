﻿using Kinara.Universal.Data.Model;
using Kinara.Universal.Data.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Universal.Data.Services
{
    public interface IEmployeeService
    {
        List<EmployeeViewModel> GetEmployeeService(EmployeeInputParams employeeInputParams);
        LoginViewModel EmployeeLogin(EmployeeInputParams employeeInputParams);
    }
}
