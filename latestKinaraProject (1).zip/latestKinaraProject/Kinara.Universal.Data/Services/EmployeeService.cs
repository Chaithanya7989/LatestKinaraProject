﻿using Kinara.Capital.Common;
using Kinara.Universal.Data.Model;
using Kinara.Universal.Data.ViewModels;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Kinara.Universal.Data.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IConfiguration _configuration;
        private readonly string mdmConnection;
        public EmployeeService(IConfiguration configuration)
        {
            _configuration = configuration;
            mdmConnection = _configuration["ConnectionStrings:MdbDataConnection"];
        }

        public LoginViewModel EmployeeLogin(EmployeeInputParams employeeInputParams)
        {
            LoginViewModel loginViewModel = null;
            try
            {
                using (MySqlConnection connection = new MySqlConnection(mdmConnection))
                {
                    connection.Open();
                    using (MySqlCommand cmd = new MySqlCommand("Mapi_Employeelogin_dynamic", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("iEmployeeCode", employeeInputParams.EmployeeCode);
                        cmd.Parameters.AddWithValue("iOfficialMailID", employeeInputParams.OfficialMailId);
                        MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
                        while (mySqlDataReader.Read())
                        {
                            loginViewModel = new LoginViewModel
                            {
                                EmployeeCode = Convert.ToString(mySqlDataReader["EmployeeCode"]),
                                EmployeeName = Convert.ToString(mySqlDataReader["Employee Name"]),
                                DesignationId = Convert.ToString(mySqlDataReader["Designation_ID"]),
                                DesignationName = Convert.ToString(mySqlDataReader["Designation_Name"]),
                                RoleId = Convert.ToString(mySqlDataReader["role_id"]),
                                AccessLevel = Convert.ToString(mySqlDataReader["access_level"]),
                                PerdixRoleCode = Convert.ToString(mySqlDataReader["perdix_role_code"])
                            };
                        }
                        mySqlDataReader.Dispose();
                    }
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
            }
            return loginViewModel;
        }

        public List<EmployeeViewModel> GetEmployeeService(EmployeeInputParams employeeInputParams)
        {
            List<EmployeeViewModel> lstemployeeViewModel = new List<EmployeeViewModel>();
            try
            {
                using (MySqlConnection connection = new MySqlConnection(mdmConnection))
                {
                    connection.Open();
                    using (MySqlCommand cmd = new MySqlCommand("Mapi_GetEmployeeDetailsDynamic", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("iEmployeeCode", employeeInputParams.EmployeeCode);
                        cmd.Parameters.AddWithValue("iRolecode", employeeInputParams.Rolecode);
                        cmd.Parameters.AddWithValue("iSpokeCode", employeeInputParams.SpokeCode);
                        cmd.Parameters.AddWithValue("ibranch_code", employeeInputParams.BranchCode);
                        cmd.Parameters.AddWithValue("iRegion_id", employeeInputParams.RegionId);
                        cmd.Parameters.AddWithValue("iZone_id", employeeInputParams.ZoneId);
                        cmd.Parameters.AddWithValue("iState_id", employeeInputParams.StateId);
                        cmd.Parameters.AddWithValue("iofficialMailID", employeeInputParams.OfficialMailId);
                        MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
                        while (mySqlDataReader.Read())
                        {
                            lstemployeeViewModel.Add(new EmployeeViewModel
                            {
                                EmployeeCode = mySqlDataReader["EmployeeCode"].ToString(),
                                EmployeeName = mySqlDataReader["Employee Name"].ToString(),
                                DesignationID = mySqlDataReader["Designation_ID"].ToString(),
                                DesignationName = mySqlDataReader["Designation_Name"].ToString(),
                                OfficialMailId = mySqlDataReader["officialMailID"].ToString(),
                                SpokeId = mySqlDataReader["Spoke_ID"].ToString(),
                                SpokeName = mySqlDataReader["SpokeName"].ToString(),
                                BranchCode = mySqlDataReader["branch_code"].ToString(),
                                BranchName = mySqlDataReader["branch_name"].ToString(),
                                RegionId = mySqlDataReader["Region_id"].ToString(),
                                RegionName = mySqlDataReader["Region_name"].ToString(),
                                ZoneId = mySqlDataReader["Zone_id"].ToString(),
                                ZoneName = mySqlDataReader["Zone_name"].ToString(),
                                StateId = mySqlDataReader["Zone_name"].ToString(),
                                StateName = mySqlDataReader["Zone_name"].ToString()
                            });
                        }
                        mySqlDataReader.Dispose();
                    }
                }
            }
            catch (CustomException ex)
            {
                throw new CustomException(ErrorCodes.Default.ToString(), _configuration);
            }

            return lstemployeeViewModel;
        }
    }
}
