﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Universal.Data
{
    public class BaseDataObject
    {
        private readonly IConfiguration _configuration;
        public BaseDataObject(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IConfiguration DbConfiguration { get { return _configuration; }  }
    }
}
