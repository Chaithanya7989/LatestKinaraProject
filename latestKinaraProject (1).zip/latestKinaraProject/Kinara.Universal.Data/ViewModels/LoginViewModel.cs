﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Universal.Data.ViewModels
{
    public class LoginViewModel
    {
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string DesignationId { get; set; }
        public string DesignationName { get; set; }
        public string RoleId { get; set; }
        public string AccessLevel { get; set; }
        public string PerdixRoleCode { get; set; }

    }
}
