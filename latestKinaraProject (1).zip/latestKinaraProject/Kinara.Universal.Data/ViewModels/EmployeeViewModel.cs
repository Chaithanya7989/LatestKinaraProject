﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Universal.Data.ViewModels
{
    public class EmployeeViewModel
    {
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string DesignationID { get; set; }
        public string DesignationName { get; set; }
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public string SpokeId { get; set; }
        public string SpokeName { get; set; }
        public string HubId { get; set; }
        public string HubName { get; set; }
        public string RegionId { get; set; }
        public string RegionName { get; set; }
        public string ZoneId { get; set; }
        public string ZoneName { get; set; }
        public string StateId { get; set; }
        public string StateName { get; set; }
        public string OfficialMailId { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }

    }
}
