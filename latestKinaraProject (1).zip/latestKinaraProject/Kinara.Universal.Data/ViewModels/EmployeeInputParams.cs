﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Universal.Data.ViewModels
{
    public class EmployeeInputParams
    {
        public string EmployeeCode { get; set; }
        public string Rolecode { get; set; }
        public string SpokeCode { get; set; }
        public string BranchCode { get; set; }
        public string RegionId { get; set; }
        public string ZoneId { get; set; }
        public string StateId { get; set; }
        public string OfficialMailId { get; set; }
    }
}
