﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kinara.Universal.Data.Model
{
    public class EmployeeMaster
    {
        public string EmployeeCode { get; set; }
        public string OfficialMailID { get; set; }
        public string RoleCode { get; set; }
        public string RoleDescription { get; set; }
        public string L1ManagerCode { get; set; }
        public string L2ManagerCode { get; set; }
        public string LocationCode { get; set; }

        public string Location { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string SpokeCode { get; set; }
        public string SpokeName { get; set; }
        public string EmploymentStatus { get; set; }
    }


    public class DwPartnerMaster
    {
        public int Id { get; set; }
        public int Version { get; set; }
        public string PartnerCode { get; set; }
        public string PartnerName { get; set; }
        public int ExternalPartner { get; set; }
        public string PartnerAddress { get; set; }
        public string PartnerCin { get; set; }
        public string PartnerRBI { get; set; }
        public string PartnerFullname { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedAt { get; set; }
        public string LastEditedBy { get; set; }
        public string LastEditedAt { get; set; }
        public string UploadBranchName { get; set; }
    }
}
