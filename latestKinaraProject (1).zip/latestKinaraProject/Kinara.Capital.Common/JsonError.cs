﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Capital.Common
{
    public class JsonError
    {
        public string Status { get; set; }
        public bool Success { get; set; }
        public CustomError Error { get; set; }
    }
}
