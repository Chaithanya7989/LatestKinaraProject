﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Capital.Common
{
    public class CustomError
    {
        public string Code { get; set; }
        public string Title { get; set; }
        public string Detail { get; set; }
        public string DocUrl { get; set; }
        public string TraceId { get; set; }
    }
}
