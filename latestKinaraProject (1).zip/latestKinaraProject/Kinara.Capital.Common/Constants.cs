﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kinara.Capital.Common
{
    public class Constants
    {
        public const string AuthorizationTokenHeader = "Authorization";
        public const string JsonContentType = "application/json";
        public const string UnAuthorizedRequestMessage = "Authorization has been denied for this request";
        public const string BearerAuthTokenKey = "Bearer";
    }
}
